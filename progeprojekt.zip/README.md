# progeprojekt

praeguse kokkuvõte:

milleni võiks edasi areneda- 
  mänguloogika: 
  - algne sõnavara selgeks levelitega
  - kui võimalik siis võiks saada õpetusfaasis nupu panna, et vajutades ütleb hääl sulle sõna häälduse- peab uurima kuidas
  - siis küsib tõlget eesti keelest hispaania keelde
  - raskemad levelid kasutab konteksti, peab valima valikvastuste seast õige sõna lünka nt
  - mängutulemused json programm on ka veel vaja teha

  graafiline pool:
  - teha ilusaks ja kasutajasõbralikuks



koostöö ja rollid:
Koostöö on sujunud, kuid rolle oleks paremini saanud jagada. Siiani me ei andnud otseselt kindlaid ülesandeid üksteisele või ei jaganud ajaliselt ära kui palju mõlemad teevad. Kokkuvõttes saime ühele lainele ja tegelesime mõlemad programmiga umbes 8-9 tundi.